CREATE DATABASE  tumbacollege;

USE tumbacollege;

CREATE TABLE  students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    regno VARCHAR(20) NOT NULL UNIQUE,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    gender VARCHAR(10),
    dob DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
