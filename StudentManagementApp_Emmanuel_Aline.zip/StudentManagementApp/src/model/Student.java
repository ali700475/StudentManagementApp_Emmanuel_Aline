package model;

import java.sql.Date;

public class Student {
    private int id;
    private String regno;
    private String firstname;
    private String lastname;
    private String email;
    private String phone;
    private String gender;
    private Date dob;

    public Student() {}

    public Student(String regno, String firstname, String lastname, String email, String phone, String gender, Date dob) {
        this.regno = regno;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.dob = dob;
    }

    public Student(int id, String regno, String firstname, String lastname, String email, String phone, String gender, Date dob) {
        this.id = id;
        this.regno = regno;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.dob = dob;
    }

    // getters & setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getRegno() { return regno; }
    public void setRegno(String regno) { this.regno = regno; }

    public String getFirstname() { return firstname; }
    public void setFirstname(String firstname) { this.firstname = firstname; }

    public String getLastname() { return lastname; }
    public void setLastname(String lastname) { this.lastname = lastname; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public Date getDob() { return dob; }
    public void setDob(Date dob) { this.dob = dob; }
}
