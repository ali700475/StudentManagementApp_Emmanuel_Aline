package util;

import java.util.regex.Pattern;

public class Validator {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private static final Pattern REGNO = Pattern.compile("^[A-Za-z0-9-]{3,20}$");
    private static final Pattern PHONE = Pattern.compile("^[0-9+]{7,15}$");

    public static boolean isEmailValid(String email) {
        return email != null && EMAIL.matcher(email).matches();
    }

    public static boolean isRegnoValid(String regno) {
        return regno != null && REGNO.matcher(regno).matches();
    }

    public static boolean isPhoneValid(String phone) {
        return phone == null || phone.isEmpty() || PHONE.matcher(phone).matches();
    }
}
