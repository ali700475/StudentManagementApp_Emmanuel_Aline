package dao;

import model.Student;
import java.util.List;

public interface StudentDAO {
    boolean addStudent(Student s) throws Exception;
    List<Student> getAllStudents() throws Exception;
    boolean updateStudent(Student s) throws Exception;
    boolean deleteStudent(int id) throws Exception;
    Student findById(int id) throws Exception;
}
