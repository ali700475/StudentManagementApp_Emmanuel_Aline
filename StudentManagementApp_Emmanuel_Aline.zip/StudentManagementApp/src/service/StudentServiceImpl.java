package service;

import dao.StudentDAO;
import dao.StudentDAOImpl;
import model.Student;
import java.util.List;

public class StudentServiceImpl implements StudentService {
    private final StudentDAO dao = new StudentDAOImpl();

    @Override
    public boolean registerStudent(Student s) throws Exception {
        return dao.addStudent(s);
    }

    @Override
    public List<Student> listStudents() throws Exception {
        return dao.getAllStudents();
    }

    @Override
    public boolean editStudent(Student s) throws Exception {
        return dao.updateStudent(s);
    }

    @Override
    public boolean removeStudent(int id) throws Exception {
        return dao.deleteStudent(id);
    }
}
