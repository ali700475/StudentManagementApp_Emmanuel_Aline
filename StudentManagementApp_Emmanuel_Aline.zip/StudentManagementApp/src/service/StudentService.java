package service;

import model.Student;
import java.util.List;

public interface StudentService {
    boolean registerStudent(Student s) throws Exception;
    List<Student> listStudents() throws Exception;
    boolean editStudent(Student s) throws Exception;
    boolean removeStudent(int id) throws Exception;
}
