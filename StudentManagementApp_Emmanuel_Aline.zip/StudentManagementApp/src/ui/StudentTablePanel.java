package ui;

import model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class StudentTablePanel extends JPanel {
    private final StudentTableModel tableModel = new StudentTableModel();
    private final JTable table = new JTable(tableModel);
    private final JTextField tfSearch = new JTextField(20);

    public StudentTablePanel(){
        setLayout(new BorderLayout(5,5));
        setBorder(BorderFactory.createTitledBorder("Student Records"));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search:"));
        tfSearch.setBorder(BorderFactory.createLineBorder(Color.GRAY,1,true));
        searchPanel.add(tfSearch);
        add(searchPanel, BorderLayout.NORTH);

        table.setFillsViewportHeight(true);
        table.setRowHeight(28);
        table.setSelectionBackground(new Color(51,153,255));
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(new Color(220,220,220));
        table.setShowGrid(true);

        // Zebra rows
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable t,Object val,boolean isSel,boolean hasFocus,int row,int col){
                super.getTableCellRendererComponent(t,val,isSel,hasFocus,row,col);
                if(!isSel) setBackground(row%2==0?Color.WHITE:new Color(245,245,245));
                return this;
            }
        });

        // Header styling
        JTableHeader th = table.getTableHeader();
        th.setBackground(new Color(51,153,255));
        th.setForeground(Color.WHITE);
        th.setFont(new Font("Arial",Font.BOLD,13));

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    public void setStudents(List<Student> students){ tableModel.setStudents(students); }
    public List<Student> getAllStudents(){ return tableModel.getAllStudents(); }
    public Student getSelectedStudent(){ int row=table.getSelectedRow(); return row>=0?tableModel.getStudentAt(row):null; }
    public JTextField getSearchField(){ return tfSearch; }
    public JTable getTable(){ return table; }

    public void filter(String keyword){
        List<Student> filtered = tableModel.getAllStudents().stream()
                .filter(s-> s.getRegno().toLowerCase().contains(keyword.toLowerCase())||
                            s.getFirstname().toLowerCase().contains(keyword.toLowerCase())||
                            s.getLastname().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
        tableModel.setStudents(filtered);
    }
}
