package ui;

import model.Student;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

public class StudentFormPanel extends JPanel {
    private final JTextField tfId = new JTextField(20);
    private final JTextField tfRegno = new JTextField(20);
    private final JTextField tfFirst = new JTextField(20);
    private final JTextField tfLast = new JTextField(20);
    private final JTextField tfEmail = new JTextField(20);
    private final JTextField tfPhone = new JTextField(20);
    private final JComboBox<String> cbGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
    private final JTextField tfDob = new JTextField(20);

    public StudentFormPanel() {
        setLayout(new GridBagLayout());
        setBackground(new Color(245,245,245));
        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200,200,200),1),
                "Student Details", 0, 0, new Font("Arial",Font.BOLD,14), new Color(60,60,60)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6,6,6,6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        int row = 0;

        addField("ID:", tfId, gbc, row++);
        tfId.setEditable(false);
        addField("RegNo:", tfRegno, gbc, row++);
        addField("First Name:", tfFirst, gbc, row++);
        addField("Last Name:", tfLast, gbc, row++);
        addField("Email:", tfEmail, gbc, row++);
        addField("Phone:", tfPhone, gbc, row++);
        addField("Gender:", cbGender, gbc, row++);
        addField("DOB:", tfDob, gbc, row++);

        addPlaceholder(tfDob, "yyyy-mm-dd");
    }

    private void addField(String label, JComponent field, GridBagConstraints gbc, int row) {
        gbc.gridy = row;

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Arial",Font.PLAIN,12));
        add(lbl, gbc);

        gbc.gridy = row;
        gbc.gridx = 1;
        field.setBorder(new LineBorder(new Color(180,180,180),1,true));
        add(field, gbc);

        gbc.gridx = 0; // reset for next row
    }

    private void addPlaceholder(JTextField tf, String placeholder) {
        tf.setForeground(Color.GRAY);
        tf.setText(placeholder);
        tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if(tf.getText().equals(placeholder)){ tf.setText(""); tf.setForeground(Color.BLACK); }
            }
            public void focusLost(java.awt.event.FocusEvent e) {
                if(tf.getText().isEmpty()){ tf.setForeground(Color.GRAY); tf.setText(placeholder); }
            }
        });
    }

    public Student getFormStudent() {
        Student s = new Student();
        try { if(!tfId.getText().trim().isEmpty()) s.setId(Integer.parseInt(tfId.getText().trim())); } catch(Exception ignored){}
        s.setRegno(tfRegno.getText().trim());
        s.setFirstname(tfFirst.getText().trim());
        s.setLastname(tfLast.getText().trim());
        s.setEmail(tfEmail.getText().trim());
        s.setPhone(tfPhone.getText().trim());
        s.setGender((String) cbGender.getSelectedItem());
        try { if(!tfDob.getText().trim().isEmpty()) s.setDob(java.sql.Date.valueOf(tfDob.getText().trim())); } catch(Exception ignored){}
        return s;
    }

    public void setFormStudent(Student s) {
        if(s==null){ clear(); return; }
        tfId.setText(String.valueOf(s.getId()));
        tfRegno.setText(s.getRegno());
        tfFirst.setText(s.getFirstname());
        tfLast.setText(s.getLastname());
        tfEmail.setText(s.getEmail());
        tfPhone.setText(s.getPhone());
        cbGender.setSelectedItem(s.getGender());
        tfDob.setText(s.getDob()!=null?s.getDob().toString():"");
    }

    public void clear() {
        tfId.setText(""); tfRegno.setText(""); tfFirst.setText("");
        tfLast.setText(""); tfEmail.setText(""); tfPhone.setText("");
        cbGender.setSelectedIndex(0); tfDob.setText("");
    }
}
