package ui;

import model.Student;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class StudentTableModel extends AbstractTableModel {
    private List<Student> students = new ArrayList<>();
    private final String[] columns = {"ID","RegNo","First Name","Last Name","Email","Phone","Gender","DOB"};

    public void setStudents(List<Student> students) {
        this.students = students;
        fireTableDataChanged();
    }

    public List<Student> getAllStudents(){ return students; }
    public Student getStudentAt(int row){ return (row>=0 && row<students.size())?students.get(row):null; }

    @Override public int getRowCount(){ return students.size(); }
    @Override public int getColumnCount(){ return columns.length; }
    @Override public String getColumnName(int col){ return columns[col]; }
    @Override public Object getValueAt(int row, int col){
        Student s = students.get(row);
        return switch(col){
            case 0->s.getId();
            case 1->s.getRegno();
            case 2->s.getFirstname();
            case 3->s.getLastname();
            case 4->s.getEmail();
            case 5->s.getPhone();
            case 6->s.getGender();
            case 7->s.getDob();
            default->null;
        };
    }
}
