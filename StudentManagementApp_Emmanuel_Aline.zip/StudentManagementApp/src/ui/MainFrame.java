package ui;

import model.Student;
import service.StudentService;
import service.StudentServiceImpl;
import util.Validator;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {
    private final StudentService service = new StudentServiceImpl();
    private final StudentFormPanel formPanel = new StudentFormPanel();
    private final StudentTablePanel tablePanel = new StudentTablePanel();

    private final JButton btnAdd = new JButton("Add");
    private final JButton btnUpdate = new JButton("Update");
    private final JButton btnDelete = new JButton("Delete");
    private final JButton btnClear = new JButton("Clear");
    private final JButton btnReload = new JButton("Reload");

    public MainFrame() {
        setTitle("Student Management App");
        setSize(1200,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5,5));

        initLayout();
        initActions();
        loadStudents();
    }

    private void initLayout(){
        JPanel topPanel = new JPanel(new BorderLayout(5,5));
        topPanel.add(formPanel, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,10,5));
        styleButton(btnAdd, new Color(51,153,255)); // blue
        styleButton(btnUpdate, new Color(51,153,255)); // blue
        styleButton(btnDelete, new Color(220,50,50)); // red
        styleButton(btnClear, new Color(220,50,50)); // red
        styleButton(btnReload, new Color(51,153,255)); // blue

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete); btnPanel.add(btnClear); btnPanel.add(btnReload);

        topPanel.add(btnPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }

    private void styleButton(JButton btn, Color color){
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial",Font.BOLD,12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(5,15,5,15));
        btn.addMouseListener(new java.awt.event.MouseAdapter(){
            public void mouseEntered(java.awt.event.MouseEvent e){ 
                btn.setBackground(color.darker()); 
            }
            public void mouseExited(java.awt.event.MouseEvent e){ 
                btn.setBackground(color); 
            }
        });
    }

    private void initActions(){
        btnAdd.addActionListener(e -> onAdd());
        btnUpdate.addActionListener(e -> onUpdate());
        btnDelete.addActionListener(e -> onDelete());
        btnClear.addActionListener(e -> formPanel.clear());
        btnReload.addActionListener(e -> loadStudents());

        // Search Box filter
        tablePanel.getSearchField().getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e){ filter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e){ filter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e){ filter(); }
            private void filter(){ tablePanel.filter(tablePanel.getSearchField().getText().trim()); }
        });

        // Click on table row to populate form
        tablePanel.getTable().getSelectionModel().addListSelectionListener(e -> {
            Student s = tablePanel.getSelectedStudent();
            if(s != null) formPanel.setFormStudent(s);
        });
    }

    private void loadStudents(){
        try {
            List<Student> students = service.listStudents();
            tablePanel.setStudents(students);
        } catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error loading students: "+ex.getMessage());
        }
    }

    private void onAdd(){
        try {
            Student s = formPanel.getFormStudent();
            String v = validateStudent(s);
            if(v != null){ JOptionPane.showMessageDialog(this,v); return; }

            boolean ok = service.registerStudent(s);
            if(ok){ JOptionPane.showMessageDialog(this,"Student added"); loadStudents(); formPanel.clear(); }
            else JOptionPane.showMessageDialog(this,"Failed to add student");
        } catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());
        }
    }

    private void onUpdate(){
        try {
            Student s = formPanel.getFormStudent();
            if(s.getId() == 0){ JOptionPane.showMessageDialog(this,"Select a student"); return; }

            String v = validateStudent(s);
            if(v != null){ JOptionPane.showMessageDialog(this,v); return; }

            boolean ok = service.editStudent(s);
            if(ok){ JOptionPane.showMessageDialog(this,"Student updated"); loadStudents(); formPanel.clear(); }
            else JOptionPane.showMessageDialog(this,"Failed to update student");
        } catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());
        }
    }

    private void onDelete(){
        try {
            Student s = formPanel.getFormStudent();
            if(s.getId() == 0){ JOptionPane.showMessageDialog(this,"Select a student"); return; }

            int choice = JOptionPane.showConfirmDialog(this,"Confirm delete?","Delete",JOptionPane.YES_NO_OPTION);
            if(choice != JOptionPane.YES_OPTION) return;

            boolean ok = service.removeStudent(s.getId());
            if(ok){ JOptionPane.showMessageDialog(this,"Deleted"); loadStudents(); formPanel.clear(); }
            else JOptionPane.showMessageDialog(this,"Failed to delete student");
        } catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());
        }
    }

    private String validateStudent(Student s){
        if(!Validator.isRegnoValid(s.getRegno())) return "Invalid RegNo!";
        if(s.getFirstname().isEmpty()) return "First name required!";
        if(s.getLastname().isEmpty()) return "Last name required!";
        if(!Validator.isEmailValid(s.getEmail())) return "Invalid email!";
        if(!Validator.isPhoneValid(s.getPhone())) return "Invalid phone!";
        return null;
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
